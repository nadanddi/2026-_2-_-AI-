# submission_23 (2026-10-13, 집 클로드, 가설 검정)
- 온도: 13회차 온도 + TNA8 앵커(v15R 짝 = HP2 짝 또는 v15R 확신 >= .8; 온도/linker_v15r/v15r_eval_pkg.py -> 온도/code/make_temp_v23_tna8.py) -> 온도/temp_candidate_v23.csv
- EC: 12회차 EC(EC/w2only_post.py) + B5 같은 날 고EC 배타 내림 .290(EC/b5_post.py) -> EC/output_23/ec_b5.csv
- 결합: merge_temp_ec_v23.py -> submission_23.csv / 규정 검사·전 과정 재현: checks_v23.py <원본 CSV 폴더> -> checks_v23.log
- 자세한 내용: 설명자료_23_일치앵커TNA8_고EC배타B5_가설검정.md

# submission_22 (2026-10-12, 집 클로드, 가설 검정)
- 온도: 11회차 온도 + 짝찾기기 v7 앵커, 측정 감쇠(온도/code/make_temp_v22_anchor.py) -> 온도/temp_candidate_v22.csv
- EC: 9회차 EC + EA2 짝찾기기 v7 앵커(EC/ea2_post.py) -> EC/output_21/ec_ea2.csv
- 결합: merge_temp_ec_v22.py -> submission_22.csv / 규정 검사: checks_v22.py <원본 CSV 폴더> (ALL PASS)
- 자세한 내용: 설명자료_22_측정감쇠앵커_v7EC앵커_가설검정.md

# submission_21 (2026-10-12, 집 클로드, 규정 정리판 + 짝찾기기 v7)
- 온도: 11회차 온도 + 짝찾기기 v7 앵커(온도/linker_v7) → 온도/temp_candidate_v21.csv
- EC: 9회차 EC + EA2 짝찾기기 v7 앵커(EC/ea2_post.py) → EC/output_21/ec_ea2.csv
- 결합: merge_temp_ec_v21.py → submission_21.csv / 규정 검사: checks_v21.py <원본 CSV 폴더> (ALL PASS)
- 자세한 내용: 설명자료_21_짝찾기v7_다른온실학습기록.md

# submission_20 (2026-10-11, 집 클로드, 규정 정리판)
- 온도: 11회차 온도 + 짝찾기기 v5 앵커(온도/linker_v5) → 온도/temp_candidate_v20.csv
- EC: 9회차 EC + EA1 짝찾기기 v5 앵커(EC/ea1_post.py) → EC/output_20/ec_ea1.csv
- 결합: merge_temp_ec_v20.py → submission_20.csv / 규정 검사: checks_v20.py <원본 CSV 폴더> (ALL PASS)
- 자세한 내용: 설명자료_20_짝찾기v5_규정정리판.md

# submission_19 (2026-10-11, 집 클로드, 가설 검정)
- 온도: 11회차 온도(temp_candidate_v18.csv) + 짝찾기 앵커(온도/linker → 온도/code/make_temp_v19_anchor.py) → 온도/temp_candidate_v19.csv
- EC: 9회차 EC + W2 구조 규칙 단독 (EC/w2only_post.py) → EC/output_19/ec_w2only.csv
- 결합: merge_temp_ec_v19.py → submission_19.csv / 규정 검사: checks_v19.py <원본 CSV 폴더> → checks_v19.log (ALL PASS)
- 자세한 내용: 설명자료_19_짝찾기앵커_EC구조규칙단독_가설검정.md

# submission_18 (2026-10-11, 집 클로드, 가설 검정)
- 온도: 9회차 W40G-S(온도/temp_candidate_v13.csv) + 사슬 인식 새벽 보정 → 온도/temp_candidate_v18.csv (온도/code/make_temp_v18_chain.py)
- EC: 9회차 EC 구성원(EC/output_14) + B4 + HG3 + W2 구조 규칙 → EC/output_18/ec_c18.csv (EC/c18post.py)
- 결합: merge_temp_ec_v18.py → submission_18.csv / 규정 검사: checks_v18.py → checks_v18.log (ALL PASS)
- 자세한 내용: 설명자료_18_사슬새벽보정_EC구조규칙_가설검정.md

# 팜모니 — 정형데이터 미션 재현 패키지 (submission_17)

**submission_17 = 온도 W40G-S + 날 단위 문턱 GRU 멤버 + EC 15.** 이 패키지는 submission_14 패키지(아래 원문)에 15·16·17 파일을 더한 것입니다.

| 열 | 내용 | 생성 | 산출 |
|---|---|---|---|
| sub_temp | 9회차 W40G-S + 0.1·g·h10·(GRU − W40G-S): 따뜻한 날(그날 실내 최저 ≥ 10℃ 근처)의 따뜻한 시각에만 GRU 10% | `온도/code/make_submission_v17_temp.py ../output` | `온도/temp_candidate_v17.csv` |
| sub_ec | EC 15: 9회차 EC 구성에서 일평균 EC ≥ 1.2 학습일 30일 제외 | `cd EC` → `python -B -u reproduce_15.py --output 새출력폴더` | `EC/output_15/submission_15.csv` |

결합: `python merge_temp_ec_v17.py 온도/temp_candidate_v17.csv EC/output_15/submission_15.csv 결합.csv` → `submission_17.csv`와 같아야 합니다.
규정 검사: `cd 온도/code` → `python temp_v17_checks.py`.
상세 설명: `설명자료_17_GRU날문턱_고EC제외_가설검정.md`.

| 파일 | SHA-256 |
|---|---|
| submission_17.csv | `7f02bcd7eb08b4c7d98e5f2130c0788dc6be7c929f65b00f08d63b2900f814de` |
| 온도/temp_candidate_v17.csv | `7a29721190e8049a6bc13a02fee11cdef1359c75ff8f708c9df4e8bb24f46e3d` |

(submission_16 안내는 `설명자료_16_NOH0_고EC제외_가설검정.md` 참조)

---

## (원문) submission_14 패키지 안내

제1회 전국 농과계 대학 농업 AI 경진대회, 정형데이터 미션.
최종 답안 `submission_14.csv` (1,440행, row_id·sub_temp·sub_ec)는 두 부분으로 만들어집니다.

| 열 | 담당 | 폴더 | 산출 파일 |
|---|---|---|---|
| sub_temp | 온도 모델 W40G-S (8회차 W40G(실제 0.5160)에서 Codex·TabPFN의 `day` 를 계절 지표로 교체, 리더보드 판정용) | `온도/` | `temp_candidate_v13.csv` 의 sub_temp |
| sub_ec | EC 모델 14 (계절 v2 + DP1 운영 순서 특징 + SG2 이웃 학습일 보정) | `EC/` | `submission_14.csv` 의 sub_ec (EC 전달본, sub_temp 빈칸) |

두 열은 `merge_temp_ec_v14.py` 가 row_id로 결합합니다(ID 유일성·같은 집합·1,440행·유한값 검사,
온도 파일 행 순서 = sample_submission 순서, UTF-8, 소수 6자리).

## 재현 절차

1. **온도**: `온도/README.md` 2절. 대회 원본 CSV 3개를 `온도/data/` 에 넣고
   ```bash
   cd 온도/code
   python make_submission_v13_temp.py ../output   # → 온도/output/temp_candidate_v13.csv (CPU 약 20분)
   python temp_v13_checks.py                       # 규정 검사 7개 ALL PASS
   ```
2. **EC**: `EC/설명자료_14_EC_SG2.md`. EC 패키지는 필요한 입력·체크포인트를 동봉합니다.
   ```bash
   cd EC
   python -B -u reproduce.py --output 새출력폴더    # → EC 전달본 (EC/submission_14.csv 와 같음, EC/manifest.json)
   ```
3. **결합**
   ```bash
   python merge_temp_ec_v14.py 온도/output/temp_candidate_v13.csv EC/submission_14.csv 결합_새이름.csv
   ```
   결과가 동봉한 `submission_14.csv` 와 같아야 합니다.

## 해시 (SHA-256)

| 파일 | SHA-256 |
|---|---|
| submission_14.csv | `f2fe5cf7e5299c2c0f2ac39f0e071066744b0c75ea19e1d7dff1e3a6282ba18a` |
| 온도/temp_candidate_v13.csv | `c899e563f4395802b4657d3a9a30ff0a6a52a4b500a59534e45c8886dbf2050f` |
| EC/submission_14.csv (EC 전달본) | `c3798821c938238350b1e5d5f552633815911da622a1113dc1bfe5dbee1b72a8` |

## 환경 차이 주의

두 패키지의 검증 환경이 다릅니다. 온도는 `온도/requirements.txt`, EC는 `EC/requirements.txt`(NumPy 2.5.3 고정 등)를 각각의
가상환경에 설치해 실행하세요. 공개 사전학습 모델 TabPFN v2 회귀(Prior Labs)를 두 모델 모두 사용하며, 외부 데이터·원격 추론은
사용하지 않습니다. 생성형 AI 사용 내역은 각 폴더 문서에 있습니다(Anthropic Claude: 온도, OpenAI Codex: EC).
