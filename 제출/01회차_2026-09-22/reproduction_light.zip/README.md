# 정형데이터 미션 재현 패키지

딸기 온실의 환경·구동기 기록으로 같은 시간 구간의 배지 온도(`sub_temp`)와 배지 EC(`sub_ec`)를 추정합니다.
이 패키지는 문제설명서 8.2절(재현 검증)에 맞춰 코드·모델·실행 안내·자료 사용 내역을 담고 있습니다.

## 1. 실행 환경

| 항목 | 값 |
|---|---|
| OS | Windows 11 |
| Python | 3.7.9 |
| numpy | 1.21.6 |
| pandas | 1.3.5 |
| scikit-learn | 1.0.2 |
| lightgbm | 4.6.0 |
| joblib | 1.3.2 |

설치:

```
pip install numpy==1.21.6 pandas==1.3.5 scikit-learn==1.0.2 lightgbm==4.6.0 joblib==1.3.2
```

## 2. 폴더 구성

```
정형데이터/            대회 원본 CSV 3개 (train_X.csv, train_y.csv, test_X.csv) — 직접 넣어야 함
code/
  common.py            데이터 로딩, 검증 분할(블록 CV), 공용 함수
  features_v2.py       인과적 피처 생성기 (최종 모델이 쓰는 피처 정의)
  make_submission.py   원본 CSV → submission.csv (학습·저장·추론·검증 한 번에)
  causality_test.py    규정 검사: 미래 입력 불변성·정답 비참조·행 순서 독립성
  cv.py, model_v*.py, experiments.py, ablation.py, final_choice.py, compare_v5.py ...
                       모델 선택에 쓴 실험 스크립트 (재현에 필요하지 않음, 근거 자료)
  *.log                위 실험들의 실행 기록
models/
  models.joblib        학습 완료된 추정기 9개 + 각 모델이 쓰는 피처 목록 (zlib 압축)
  manifest.json        라이브러리 버전, 입력 파일 SHA-256, 파라미터, 피처 목록, 제출 파일 해시
submission.csv         제출 파일 (1,440행, row_id / sub_temp / sub_ec)
```

## 3. 재현 방법

원본 CSV 3개를 `정형데이터/` 폴더에 넣은 뒤:

```
cd code
python causality_test.py        # 규정 검사 (ALL PASS 여야 함, 약 1분)
python make_submission.py       # 학습 + 모델 저장 + submission.csv 생성 (약 3분)
```

저장된 모델로 예측만 다시 하려면:

```
python make_submission.py --predict-only
```

두 방법 모두 `submission.csv`를 **바이트 단위로 동일하게** 만듭니다 (LightGBM `deterministic=True, force_col_wise=True`, 모든 시드 고정). 재학습 두 번, 저장 모델 재예측 한 번을 비교해 동일함을 확인했습니다. 생성된 파일의 SHA-256은 `models/manifest.json`의 `submission_sha256`과 일치해야 합니다.

## 4. 모델 요약

| 타깃 | 모델 | 피처 수 | 시드 |
|---|---|---|---|
| sub_temp | LightGBM (Huber 손실) | 98 | 3개 평균 |
| sub_ec | ExtraTrees(100그루, min_samples_leaf=8) 와 LightGBM(Huber) 의 평균 | 68 | 각 3개 평균 |

- 두 타깃은 별도 모델입니다. 학습에는 정답이 있는 F13·F47의 9,600행만 사용했습니다 (다른 49개 온실은 검증 결과 도움이 되지 않아 제외).
- `in_rad`, `act_side`, `act_valve`, `act_cool`, `act_pump`는 평가 온실에서 전부 결측이라 사용하지 않습니다.
- `sub_ec` 예측값은 학습 정답의 관측 범위 [0.062, 3.46]로 클리핑합니다.
- 파라미터 전체는 `models/manifest.json`의 `params`에 있습니다.

## 5. 규정 준수 (문제설명서 5절)

- 모든 피처는 **같은 온실의 해당 시각과 그 이전 입력만** 사용합니다. 지연값(shift), 인과적 지수가중평균(ewm), 현재 시각에서 닫히는 롤링 통계, 전일 집계(shift 1·2일), 당일 0시부터 현재까지의 확장 평균, 작기 누적합만 씁니다. 중앙 이동평균·bfill·전체 하루 평균은 쓰지 않습니다.
- `test_X`의 입력은 같은 온실의 과거 입력으로서 피처 계산에 사용합니다 (예: 평가 블록 둘째 날의 "전일 평균"은 첫째 날 입력으로 계산). 정답은 사용하지 않습니다.
- `train_y`는 학습에만 쓰며 피처로 쓰지 않습니다. 평가 블록 경계마다 하루가 비어 있어 과거 정답 기반 피처는 평가 시점에 존재할 수도 없습니다.
- `causality_test.py`가 위 조건을 자동 검사합니다: (1) 특정 시각 이후의 입력을 교란·삭제해도 그 이전 행의 피처 125개가 전부 불변, (2) 피처 생성기는 입력 열만 받음, (3) 행 순서를 섞어도 결과 동일.
- 추론 단계에서 외부 API·원격 서비스·외부 데이터 조회를 사용하지 않습니다.

## 6. 자료 사용 내역 (문제설명서 8.1절)

- **외부 데이터**: 사용하지 않음.
- **사전학습 모델**: 사용하지 않음.
- **생성형 AI**: 코드 작성·데이터 분석·실험 설계에 Claude Code(Anthropic, Claude Opus)를 사용했습니다. 모델 학습 데이터나 예측값 생성에는 관여하지 않으며, 대회 자료를 외부 서비스로 전송하지 않았습니다.
- **문헌**: 물리 피처 설계에 아래 공개 자료의 공식을 참고했습니다 (데이터가 아니라 수식만 사용).
  - Baille et al. (1994) 간이 Penman-Monteith 증산 모델 — 증산 프록시 `transp_pm`
  - FAO-56 3장 Eq. 11 포화수증기압 — VPD 계산
  - 농촌진흥청·농사로 딸기 수경재배 급액 지침 — 작기 누적·전일 집계 피처의 근거

## 7. 검증 방법과 결과 (참고)

평가 자료와 같은 구조(5·10·10·5일 연속 블록, 앞뒤 1일 버퍼)로 학습 정답을 잘라 모의 채점했습니다. 평가 구간이 작기 후반(183일차 이후)이라 그 구간 점수를 기준으로 모델을 골랐고, 단일 분할의 노이즈(±0.02)를 줄이기 위해 서로 다른 분할 7개의 평균을 봤습니다.

| 타깃 | 후반부 RMSE (7분할 평균) | 전 기간 RMSE |
|---|---|---|
| sub_temp | 0.887 ℃ | 0.774 |
| sub_ec | 0.296 dS/m | 0.260 |

(`code/final_cv.py`로 재계산 가능, 기록은 `code/logs/final_cv.log`)

이 값은 로컬 모의 채점이며 대회 점수가 아닙니다.
