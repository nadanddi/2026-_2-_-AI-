# -*- coding: utf-8 -*-
"""EA4 (2026-10-15 집 클로드; 사용자 '5점 모델별 잘된 부분 추출' 검토 중 RV2(사후)에서 E4 = F5E + v7 확신 링커 어제 EC 앵커가 모든 상황 칸 개선).  사전 고정(커밋 후 실행).  EC.
EA3 와 같은 판정·자료(SZ2 독립 기본 예측 위 F5E), 짝 표만 다름: 링커 v7(local/linker_v7/cv_all400_choice_v7m.csv; 14·15회차 온도 앵커와 같은 v7,
  다른 농장 평가 입력·같은 농장 뒷번호 입력 안 씀) 확신 짝 = p ≥ .8 & 정답 있는 전날 & |dT_air| ≤ 1.5 (6.574 EA1/EA2 규칙), 그 폴드 검증 기록이면 안 씀.
  [RV2 에서 결과를 본 뒤의 확인 판정이므로 '사후 후보의 같은 자료 재판정' 한계 명시 — 새 자료가 아님]
판정(EC 분야 배정 규칙, 단일 α .025): (1) P2LOO·EL1 3시드 모두 2차 dSSE < 0 & (P2LOO 블록 P(악화) < .025 OR 나빠진 2차 기록-칸 0); (3) DIAG10 손해 감시.
Run:  cd 집/클로드/research && PYTHONPATH="" python -u ea4_v7_anchor_on_f5e_v1.py
"""
import os, sys, pickle
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import env  # noqa: F401
import numpy as np, pandas as pd
sys.path.insert(0, os.path.join(HERE, "linker_v4")); from feat4 import EC as ECA, FARM, NUM, N, TRAIN  # noqa: E402
rid = lambda i: f"{FARM[i]}_{NUM[i]:03d}"; idx = {rid(i): i for i in range(N)}
rm = lambda e: float(np.sqrt(np.mean(np.square(e)))); SEEDS = (1357, 2468, 3579)
R = pd.read_csv(os.path.join(HERE, "nh1_rows_v1.csv.gz")); MT = pickle.load(open(os.path.join(env.LOCAL, "nh1_mt1_v1.pkl"), "rb")); EP = pickle.load(open(os.path.join(env.LOCAL, "nh2_ev3l_v1.pkl"), "rb"))
mt = np.array([MT[(v, k)][r][h] for v, k, r, h in zip(R.validator, R.fold, R.rec, R.hour)]); ev = np.array([EP[(v, k)][r][h] for v, k, r, h in zip(R.validator, R.fold, R.rec, R.hour)])
for s in SEEDS: R[f"F5E_{s}"] = .9 * ((R[f"A1_{s}"] - .1 * mt) / .9) + .1 * ev
L7 = pd.read_csv(os.path.join(env.LOCAL, "linker_v7", "cv_all400_choice_v7m.csv"), encoding="utf-8-sig")
v7set = {r for r, q, l, d in zip(L7.rec, L7.p, L7.prev_is_labelled, L7.dT_air) if q >= .8 and l and abs(d) <= 1.5}
ARMS = {"V7": .8}; PB = .025; LEDGER = {"F13_231", "F13_233", "F47_216", "F47_229", "F47_241", "F13_217", "F13_243", "F47_231"}
for arm, th in ARMS.items():
    link = {r: p for r, p, q, l, dT in zip(L7.rec, L7.prev, L7.p, L7.prev_is_labelled, L7.dT_air) if isinstance(p, str) and q >= th and l and abs(dT) <= 1.5 and r in v7set and p in idx and np.isfinite(ECA[idx[p], 23])}
    n_used = 0
    for s in SEEDS: R[f"{arm}_{s}"] = R[f"F5E_{s}"].values
    for (v, k, r), g in R.groupby(["validator", "fold", "rec"]):
        p = link.get(r)
        if p is None or p in set(R.rec[(R.validator == v) & (R.fold == k)]): continue
        ii = g.sort_values("hour").index.values; n_used += 1
        for s in SEEDS:
            q = R.loc[ii, f"F5E_{s}"].values; pm = np.cumsum(q) / np.arange(1, len(q) + 1); R.loc[ii, f"{arm}_{s}"] = q + (ECA[idx[p], 23] - pm)
    print(f"{arm}: links {len(link)}, anchored record-folds {n_used}", flush=True)
pd.set_option("display.width", 220); VER = {}
for arm in ARMS:
    rows, blocks, recd = [], {}, []
    for v in ("DIAG10", "EL1", "P2LOO"):
        g = R[R.validator == v]; y = g.y.values; p2 = g.p2.values; hi = g.hi.values; key = (g.farm + "_" + (g.day // 5).astype(str)).values; led = ~g.rec.isin(LEDGER).values
        for s in SEEDS:
            a, n = g[f"F5E_{s}"].values, g[f"{arm}_{s}"].values; d = (n - y) ** 2 - (a - y) ** 2
            fx = lambda ref, m: 100 * (rm((n - y)[m]) / rm((g[ref].values - y)[m]) - 1) if m.any() else np.nan
            rows.append(dict(val=v, seed=s, dSSE_p2=float(d[p2].sum()), dSSE_all=float(d.sum()), vsF5E_all=fx(f"F5E_{s}", np.ones(len(y), bool)), vsF5E_p2=fx(f"F5E_{s}", p2),
                             p2_high=fx(f"F5E_{s}", p2 & hi), vsSH_p2=fx(f"SH_{s}", p2), vsSH_all=fx(f"SH_{s}", np.ones(len(y), bool)), X0_p2=float(d[p2 & led].sum())))
            blocks.setdefault((v, "p2"), []).append(pd.Series(d[p2]).groupby(key[p2]).mean()); blocks.setdefault((v, "all"), []).append(pd.Series(d).groupby(key).mean())
            for r_, dd in pd.Series(d).groupby(g.rec.values).sum().items(): recd.append(dict(val=v, seed=s, rec=r_, dsse=dd, p2=int(r_[4:]) >= 179))
    S = pd.DataFrame(rows); print(f"\n=== {arm} vs F5E ==="); print(S.round(3).to_string(index=False))
    def boot(key_):
        x = pd.concat(blocks[key_], axis=1).mean(axis=1).values; m = x[np.random.default_rng(20270103).integers(0, len(x), (20000, len(x)))].mean(1); return float((m >= 0).mean()), float((m < 0).mean())
    main = S[S.val.isin(["P2LOO", "EL1"])]; c1 = bool((main.dSSE_p2 < 0).all()); pP, _ = boot(("P2LOO", "p2"))
    RD = pd.DataFrame(recd); harmed = RD[RD.val.isin(["P2LOO", "EL1"]) & RD.p2].groupby(["val", "seed", "rec"]).dsse.sum(); nh = int((harmed > 1e-6).sum())
    dg = S[S.val == "DIAG10"]; _, pb = boot(("DIAG10", "all")); c3 = not (dg.dSSE_all.mean() > 0 and pb < .025)
    print(f"(1) main cells better {int((main.dSSE_p2 < 0).sum())}/6 | P2LOO P(worse) {pP:.4f} (< {PB}) | harmed record-cells {nh} | (3) DIAG10 mean dSSE {dg.dSSE_all.mean():+.3f} share(better) {pb:.3f} -> {'PASS' if c3 else 'FAIL'}")
    t = RD.groupby("rec").dsse.mean().loc[lambda x: x.abs() > 1e-6].sort_values(); print("changed records best:", t.head(5).round(3).to_dict(), "| worst:", t.tail(5).round(3).to_dict())
    VER[arm] = c1 and (pP < PB or nh == 0) and c3; print(f"EA4 {arm}:", "ADOPT" if VER[arm] else "FAIL")
print("\nEA3:", VER)
